class OS {
  public static void main(String[] args) {

    // get the name of operating system
    String operatingSystem = System.getProperty("os.name");
    System.out.println(operatingSystem);

  }
}

/*
Windows 11
*/
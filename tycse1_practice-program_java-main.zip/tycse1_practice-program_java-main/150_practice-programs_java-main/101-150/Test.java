class Test {

}

class Main {
  public static void main(String[] args) {

    // create an object of the Test class
    Test obj = new Test();

    // print the object
    System.out.println(obj);
  }
}

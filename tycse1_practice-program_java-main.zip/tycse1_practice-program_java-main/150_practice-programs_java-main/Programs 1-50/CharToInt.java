class CharToInt {
  public static void main(String[] args) {

    // create char variables
    char a = '5';
    char b = 'c';

    // convert char variables to int
    // ASCII value of characters is assigned
    int num1 = a;
    int num2 = b;

    // print the values
    System.out.println(num1);    // 53
    System.out.println(num2);    // 99
  }
}
/*
 53
 99
 */
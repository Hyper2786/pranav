class Double_int {
  public static void main(String[] args) {

    // create double variables
    double a = 23.78D;
    double b = 52.11D;

    // convert double into int
    // using typecasting
    int c = (int)a;
    int d = (int)b;

    System.out.println(c);    // 23
    System.out.println(d);    // 52
  }
}
/*
 23
52
 */
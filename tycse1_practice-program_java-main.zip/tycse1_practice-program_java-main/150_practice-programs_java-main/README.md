# 150_practice-programs_java
Training of java programming
